package com.mineamp;

import com.mineamp.audio.MusicFolder;
import com.mineamp.command.MineAmpCommand;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MineAmpClient implements ClientModInitializer {

    public static final String MOD_ID = "mineamp";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("MineAMP loaded. It really whips the llama's ass.");
        MusicFolder.init();
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            MineAmpCommand.register(dispatcher)
        );
    }
}
