package com.mineamp.player;

import com.mineamp.audio.MusicFolder;
import com.mineamp.audio.VoiceChatSender;
import com.mineamp.audio.WavPlayer;

import java.nio.file.Path;
import java.util.List;

public class MusicPlayer {

    private static MusicPlayer instance;
    private List<String> playlist;
    private int currentIndex = 0;
    private WavPlayer currentPlayer;
    private float volume = 0.75f;

    private MusicPlayer() { playlist = MusicFolder.listTracks(); }

    public static MusicPlayer getInstance() {
        if (instance == null) instance = new MusicPlayer();
        return instance;
    }

    public void refreshPlaylist() { playlist = MusicFolder.listTracks(); }
    public List<String> getPlaylist() { return playlist; }
    public int getCurrentIndex() { return currentIndex; }

    public String getCurrentTrackName() {
        if (playlist.isEmpty()) return null;
        return playlist.get(currentIndex);
    }

    public boolean isPlaying() { return currentPlayer != null && currentPlayer.isPlaying(); }
    public float getProgress() { return currentPlayer == null ? 0f : currentPlayer.getProgress(); }
    public int getElapsedSeconds() { return currentPlayer == null ? 0 : currentPlayer.getElapsedSeconds(); }
    public float getVolume() { return volume; }

    public void setVolume(float volume) {
        this.volume = volume;
        if (currentPlayer != null) currentPlayer.setVolume(volume);
    }

    public boolean play(String filename) {
        Path track = MusicFolder.getTrack(filename);
        if (track == null) return false;
        stopInternal();
        int idx = playlist.indexOf(filename);
        if (idx >= 0) currentIndex = idx;
        currentPlayer = new WavPlayer(track);
        currentPlayer.setVolume(volume);
        currentPlayer.start();
        return true;
    }

    public boolean play() {
        if (playlist.isEmpty()) return false;
        return play(playlist.get(currentIndex));
    }

    public void stop() {
        stopInternal();
        VoiceChatSender.getInstance().closeChannel();
    }

    public void next() {
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex + 1) % playlist.size();
        play();
    }

    public void prev() {
        if (playlist.isEmpty()) return;
        currentIndex = (currentIndex - 1 + playlist.size()) % playlist.size();
        play();
    }

    private void stopInternal() {
        if (currentPlayer != null) { currentPlayer.stop(); currentPlayer = null; }
    }
}
