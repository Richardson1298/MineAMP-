package com.mineamp.audio;

import com.mineamp.MineAmpClient;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.events.EventRegistration;

public class MineAmpVoicechatPlugin implements VoicechatPlugin {

    @Override
    public String getPluginId() {
        return "mineamp";
    }

    public void initialize(VoicechatServerApi api) {
        MineAmpClient.LOGGER.info("MineAMP Voice Chat plugin initialized");
        VoiceChatSender.getInstance().setApi(api);
    }

    public void registerEvents(EventRegistration registration) {}
}
