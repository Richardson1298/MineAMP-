package com.mineamp.audio;

import com.mineamp.MineAmpClient;

import java.io.*;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicBoolean;

public class WavPlayer {

    private static final int FRAME_SIZE = 960;
    private static final int BYTES_PER_SAMPLE = 2;
    private static final int FRAME_BYTES = FRAME_SIZE * BYTES_PER_SAMPLE;

    private final Path wavPath;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread playbackThread;
    private volatile int totalFrames = 0;
    private volatile int currentFrame = 0;
    private volatile boolean finished = false;
    private volatile float volume = 0.75f;
    private Object audioTrack;

    public WavPlayer(Path wavPath) { this.wavPath = wavPath; }

    public void start() {
        if (running.get()) stop();
        running.set(true);
        finished = false;
        currentFrame = 0;
        playbackThread = new Thread(this::playbackLoop, "MineAMP-Playback");
        playbackThread.setDaemon(true);
        playbackThread.start();
    }

    public void stop() {
        running.set(false);
        if (playbackThread != null) { playbackThread.interrupt(); playbackThread = null; }
        closeAudioTrack();
        finished = true;
    }

    public boolean isPlaying() { return running.get(); }
    public boolean isFinished() { return finished; }
    public float getProgress() { return totalFrames == 0 ? 0f : (float) currentFrame / totalFrames; }
    public int getElapsedSeconds() { return (int)((currentFrame * (long)FRAME_SIZE) / 48000f); }
    public void setVolume(float v) { this.volume = Math.max(0f, Math.min(1f, v)); }

    private void playbackLoop() {
        try {
            RandomAccessFile raf = new RandomAccessFile(wavPath.toFile(), "r");
            byte[] header = new byte[44];
            raf.readFully(header);

            int channels     = (header[22] & 0xFF) | ((header[23] & 0xFF) << 8);
            int sampleRate   = (header[24] & 0xFF) | ((header[25] & 0xFF) << 8)
                             | ((header[26] & 0xFF) << 16) | ((header[27] & 0xFF) << 24);
            long dataSize    = raf.length() - 44;
            totalFrames      = (int)(dataSize / FRAME_BYTES);

            MineAmpClient.LOGGER.info("WAV: {}ch {}Hz {} frames", channels, sampleRate, totalFrames);

            initAudioTrack(sampleRate, channels);

            VoiceChatSender sender = VoiceChatSender.getInstance();
            byte[] buffer = new byte[FRAME_BYTES];

            while (running.get()) {
                int bytesRead = raf.read(buffer, 0, FRAME_BYTES);
                if (bytesRead == -1) break;
                if (bytesRead < FRAME_BYTES)
                    for (int i = bytesRead; i < FRAME_BYTES; i++) buffer[i] = 0;

                applyVolume(buffer, volume);
                writeToAudioTrack(buffer);

                if (sender.isReady()) sender.sendAudioFrame(bytesToShorts(buffer));
                currentFrame++;
            }

            raf.close();
        } catch (Exception e) {
            MineAmpClient.LOGGER.error("Playback error: {}", e.getMessage());
        } finally {
            closeAudioTrack();
            running.set(false);
            finished = true;
        }
    }

    private void initAudioTrack(int sampleRate, int channels) {
        try {
            Class<?> atClass  = Class.forName("android.media.AudioTrack");
            Class<?> fbClass  = Class.forName("android.media.AudioFormat$Builder");
            Class<?> abClass  = Class.forName("android.media.AudioAttributes$Builder");

            Object ab = abClass.newInstance();
            abClass.getMethod("setUsage", int.class).invoke(ab, 3);
            abClass.getMethod("setContentType", int.class).invoke(ab, 2);
            Object attrs = abClass.getMethod("build").invoke(ab);

            Object fb = fbClass.newInstance();
            fbClass.getMethod("setSampleRate", int.class).invoke(fb, sampleRate);
            fbClass.getMethod("setEncoding", int.class).invoke(fb, 2);
            int mask = channels == 1 ? 4 : 12;
            fbClass.getMethod("setChannelMask", int.class).invoke(fb, mask);
            Object fmt = fbClass.getMethod("build").invoke(fb);

            int minBuf = (int) atClass.getMethod("getMinBufferSize", int.class, int.class, int.class)
                .invoke(null, sampleRate, mask, 2);
            int bufSize = Math.max(minBuf, FRAME_BYTES * 4);

            Class<?> attrClass = Class.forName("android.media.AudioAttributes");
            Class<?> fmtClass  = Class.forName("android.media.AudioFormat");
            audioTrack = atClass.getConstructor(attrClass, fmtClass, int.class, int.class, int.class)
                .newInstance(attrs, fmt, bufSize, 1, 0);

            atClass.getMethod("play").invoke(audioTrack);
            MineAmpClient.LOGGER.info("AudioTrack OK");
        } catch (Exception e) {
            MineAmpClient.LOGGER.warn("AudioTrack failed (not Android?): {}", e.getMessage());
            audioTrack = null;
            // Fallback — пробуем javax.sound.sampled
            initJavaxAudio(sampleRate, channels);
        }
    }

    private Object javaxLine;

    private void initJavaxAudio(int sampleRate, int channels) {
        try {
            javax.sound.sampled.AudioFormat fmt = new javax.sound.sampled.AudioFormat(
                javax.sound.sampled.AudioFormat.Encoding.PCM_SIGNED,
                sampleRate, 16, channels, channels * 2, sampleRate, false
            );
            javax.sound.sampled.DataLine.Info info = new javax.sound.sampled.DataLine.Info(
                javax.sound.sampled.SourceDataLine.class, fmt
            );
            javaxLine = javax.sound.sampled.AudioSystem.getLine(info);
            ((javax.sound.sampled.SourceDataLine) javaxLine).open(fmt, FRAME_BYTES * 4);
            ((javax.sound.sampled.SourceDataLine) javaxLine).start();
            MineAmpClient.LOGGER.info("javax.sound fallback OK");
        } catch (Exception e) {
            MineAmpClient.LOGGER.warn("javax.sound also failed: {}", e.getMessage());
            javaxLine = null;
        }
    }

    private void writeToAudioTrack(byte[] data) {
        if (audioTrack != null) {
            try {
                audioTrack.getClass().getMethod("write", byte[].class, int.class, int.class)
                    .invoke(audioTrack, data, 0, data.length);
            } catch (Exception e) {
                MineAmpClient.LOGGER.error("AudioTrack write: {}", e.getMessage());
            }
        } else if (javaxLine != null) {
            ((javax.sound.sampled.SourceDataLine) javaxLine).write(data, 0, data.length);
        }
    }

    private void closeAudioTrack() {
        if (audioTrack != null) {
            try {
                audioTrack.getClass().getMethod("stop").invoke(audioTrack);
                audioTrack.getClass().getMethod("release").invoke(audioTrack);
            } catch (Exception ignored) {}
            audioTrack = null;
        }
        if (javaxLine != null) {
            ((javax.sound.sampled.SourceDataLine) javaxLine).stop();
            ((javax.sound.sampled.SourceDataLine) javaxLine).close();
            javaxLine = null;
        }
    }

    private static void applyVolume(byte[] buf, float vol) {
        for (int i = 0; i < buf.length - 1; i += 2) {
            short s = (short)((buf[i] & 0xFF) | (buf[i+1] << 8));
            s = (short)(s * vol);
            buf[i]   = (byte)(s & 0xFF);
            buf[i+1] = (byte)((s >> 8) & 0xFF);
        }
    }

    private static short[] bytesToShorts(byte[] bytes) {
        short[] s = new short[bytes.length / 2];
        for (int i = 0; i < s.length; i++)
            s[i] = (short)((bytes[i*2] & 0xFF) | (bytes[i*2+1] << 8));
        return s;
    }
}
