package com.mineamp.audio;

import com.mineamp.MineAmpClient;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.audiochannel.StaticAudioChannel;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;

public class VoiceChatSender {

    private static VoiceChatSender instance;
    private VoicechatServerApi api;
    private StaticAudioChannel channel;

    private VoiceChatSender() {}

    public static VoiceChatSender getInstance() {
        if (instance == null) instance = new VoiceChatSender();
        return instance;
    }

    public void setApi(VoicechatServerApi api) {
        this.api = api;
    }

    public void openChannel() {
        if (api == null) {
            MineAmpClient.LOGGER.warn("Voice Chat API not available");
            return;
        }
        try {
            channel = api.createStaticAudioChannel(UUID.randomUUID(), null, null);
            MineAmpClient.LOGGER.info("Opened static audio channel");
        } catch (Exception e) {
            MineAmpClient.LOGGER.error("Failed to open audio channel: {}", e.getMessage());
        }
    }

    public void sendAudioFrame(short[] samples) {
        if (channel == null) openChannel();
        if (channel != null) {
            // Конвертируем short[] в byte[]
            ByteBuffer buf = ByteBuffer.allocate(samples.length * 2).order(ByteOrder.LITTLE_ENDIAN);
            for (short s : samples) buf.putShort(s);
            channel.send(buf.array());
        }
    }

    public void closeChannel() {
        if (channel != null) {
            channel.flush();
            channel = null;
        }
    }

    public boolean isReady() {
        return api != null;
    }
}
