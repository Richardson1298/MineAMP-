package com.mineamp.command;

import com.mineamp.audio.MusicFolder;
import com.mineamp.player.MusicPlayer;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.network.chat.Component;

import java.util.List;

public class MineAmpCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(
            ClientCommands.literal("mineamp")
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(Component.literal("§6=== MineAMP ==="));
                    ctx.getSource().sendFeedback(Component.literal("§7/mineamp play <file> §f— играть"));
                    ctx.getSource().sendFeedback(Component.literal("§7/mineamp stop §f— стоп"));
                    ctx.getSource().sendFeedback(Component.literal("§7/mineamp list §f— список треков"));
                    ctx.getSource().sendFeedback(Component.literal("§7/mineamp next §f— следующий"));
                    ctx.getSource().sendFeedback(Component.literal("§7/mineamp prev §f— предыдущий"));
                    return 1;
                })
                .then(ClientCommands.literal("play")
                    .then(ClientCommands.argument("file", StringArgumentType.greedyString())
                        .executes(ctx -> playTrack(ctx, StringArgumentType.getString(ctx, "file")))
                    )
                    .executes(ctx -> playTrack(ctx, null))
                )
                .then(ClientCommands.literal("stop")
                    .executes(MineAmpCommand::stop)
                )
                .then(ClientCommands.literal("list")
                    .executes(MineAmpCommand::listTracks)
                )
                .then(ClientCommands.literal("next")
                    .executes(ctx -> { MusicPlayer.getInstance().next(); return 1; })
                )
                .then(ClientCommands.literal("prev")
                    .executes(ctx -> { MusicPlayer.getInstance().prev(); return 1; })
                )
        );
    }

    private static int playTrack(CommandContext<FabricClientCommandSource> ctx, String file) {
        MusicPlayer player = MusicPlayer.getInstance();
        boolean ok = file == null ? player.play() : player.play(file);
        if (ok) ctx.getSource().sendFeedback(Component.literal("§a▶ Playing: §f" + player.getCurrentTrackName()));
        else ctx.getSource().sendFeedback(Component.literal("§cТрек не найден. Используй /mineamp list"));
        return ok ? 1 : 0;
    }

    private static int stop(CommandContext<FabricClientCommandSource> ctx) {
        MusicPlayer.getInstance().stop();
        ctx.getSource().sendFeedback(Component.literal("§c■ Остановлено."));
        return 1;
    }

    private static int listTracks(CommandContext<FabricClientCommandSource> ctx) {
        List<String> tracks = MusicFolder.listTracks();
        if (tracks.isEmpty()) {
            ctx.getSource().sendFeedback(Component.literal("§eНет треков в .minecraft/mineamp/music/"));
        } else {
            ctx.getSource().sendFeedback(Component.literal("§6=== MineAMP Playlist ==="));
            for (int i = 0; i < tracks.size(); i++)
                ctx.getSource().sendFeedback(Component.literal("§7" + (i + 1) + ". §f" + tracks.get(i)));
        }
        return 1;
    }
}
