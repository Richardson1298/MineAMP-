package com.virtualwindow;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class VirtualWindowView extends View {

    // ============================================================
    // Realme C21 — экран 720x1600
    // Битые зоны по рисунку:
    //   Сверху:  240px  Слева: 180px  Снизу: 160px  Справа: 0
    // Рабочая зона: left=180, top=240, right=720, bottom=1440
    // Размер: 540x1200px
    // ============================================================

    private static final int SAFE_LEFT   = 180;
    private static final int SAFE_TOP    = 240;
    private static final int SAFE_RIGHT  = 720;
    private static final int SAFE_BOTTOM = 1440;

    private static final int SCREEN_W = 720;
    private static final int SCREEN_H = 1600;

    // Масштаб для вписывания всего экрана в рабочую зону
    // min(540/720, 1200/1600) = min(0.75, 0.75) = 0.75
    private static final float FIT_SCALE = Math.min(
        (float)(SAFE_RIGHT  - SAFE_LEFT) / SCREEN_W,
        (float)(SAFE_BOTTOM - SAFE_TOP)  / SCREEN_H
    );

    private float userZoom = 1.0f;
    private float winX = SAFE_LEFT;
    private float winY = SAFE_TOP;

    private Bitmap frameBitmap = null;

    private static final int ZONE_NONE = 0;
    private static final int ZONE_DRAG = 1;
    private int touchZone = ZONE_NONE;
    private float lastTouchX, lastTouchY;

    private Paint borderPaint;
    private Paint bgPaint;
    private Paint labelPaint;
    private Paint dimPaint;
    private Paint brokenPaint;

    public VirtualWindowView(Context context) {
        super(context);
        init();
    }

    public VirtualWindowView(Context context, WindowManager wm, WindowManager.LayoutParams lp) {
        super(context);
        init();
    }

    private void init() {
        borderPaint = new Paint();
        borderPaint.setColor(Color.CYAN);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(3f);
        borderPaint.setAntiAlias(true);

        bgPaint = new Paint();
        bgPaint.setColor(Color.argb(200, 10, 10, 30));

        labelPaint = new Paint();
        labelPaint.setColor(Color.CYAN);
        labelPaint.setTextSize(28f);
        labelPaint.setAntiAlias(true);

        dimPaint = new Paint();
        dimPaint.setColor(Color.argb(160, 0, 0, 0));

        brokenPaint = new Paint();
        brokenPaint.setColor(Color.argb(60, 255, 0, 0));
    }

    public void updateFrame(Bitmap bitmap) {
        if (bitmap != null) {
            this.frameBitmap = bitmap;
            postInvalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawRect(0, 0, getWidth(), getHeight(), dimPaint);

        float scale = FIT_SCALE * userZoom;
        float drawW = SCREEN_W * scale;
        float drawH = SCREEN_H * scale;

        canvas.drawRect(winX, winY, winX + drawW, winY + drawH, bgPaint);

        if (frameBitmap != null && !frameBitmap.isRecycled()) {
            Rect src = new Rect(0, 0, frameBitmap.getWidth(), frameBitmap.getHeight());
            RectF dst = new RectF(winX, winY, winX + drawW, winY + drawH);
            canvas.drawBitmap(frameBitmap, src, dst, null);
        } else {
            Paint txt = new Paint();
            txt.setColor(Color.WHITE);
            txt.setTextSize(30f);
            txt.setAntiAlias(true);
            canvas.drawText("Захват экрана...", winX + 20, winY + drawH / 2, txt);
        }

        canvas.drawRect(winX, winY, winX + drawW, winY + drawH, borderPaint);
        canvas.drawText("Virtual Window  " + Math.round(scale * 100) + "%", winX + 8, winY - 8, labelPaint);

        // Красная подсветка битых зон
        int w = getWidth();
        int h = getHeight();
        canvas.drawRect(0, 0, w, SAFE_TOP, brokenPaint);
        canvas.drawRect(0, SAFE_TOP, SAFE_LEFT, SAFE_BOTTOM, brokenPaint);
        canvas.drawRect(0, SAFE_BOTTOM, w, h, brokenPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float tx = event.getRawX();
        float ty = event.getRawY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                lastTouchX = tx;
                lastTouchY = ty;
                touchZone = isInsideWindow(tx, ty) ? ZONE_DRAG : ZONE_NONE;
                return true;

            case MotionEvent.ACTION_MOVE:
                if (touchZone == ZONE_DRAG) {
                    winX += tx - lastTouchX;
                    winY += ty - lastTouchY;
                    float scale = FIT_SCALE * userZoom;
                    winX = Math.max(SAFE_LEFT, Math.min(winX, SAFE_RIGHT  - SCREEN_W * scale));
                    winY = Math.max(SAFE_TOP,  Math.min(winY, SAFE_BOTTOM - SCREEN_H * scale));
                    invalidate();
                }
                lastTouchX = tx;
                lastTouchY = ty;
                return true;

            case MotionEvent.ACTION_UP:
                touchZone = ZONE_NONE;
                return true;
        }
        return super.onTouchEvent(event);
    }

    private boolean isInsideWindow(float x, float y) {
        float scale = FIT_SCALE * userZoom;
        return x >= winX && x <= winX + SCREEN_W * scale
            && y >= winY && y <= winY + SCREEN_H * scale;
    }

    public void zoomIn()  { userZoom = Math.min(userZoom + 0.1f, 2.0f); invalidate(); }
    public void zoomOut() { userZoom = Math.max(userZoom - 0.1f, 0.3f); invalidate(); }

    public void resetZoom() {
        userZoom = 1.0f;
        winX = SAFE_LEFT;
        winY = SAFE_TOP;
        invalidate();
    }
}
