package com.virtualwindow;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;

import java.nio.ByteBuffer;

public class OverlayService extends Service {

    private static final String CHANNEL_ID = "VirtualWindowChannel";
    private static final int NOTIF_ID = 1;

    private WindowManager windowManager;
    private VirtualWindowView windowView;
    private View controlPanel;

    private ScreenCaptureManager captureManager;
    private ImageReader imageReader;

    private Handler frameHandler;
    private boolean isCapturing = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundNotification();

        int resultCode = intent.getIntExtra("resultCode", -1);
        Intent data    = intent.getParcelableExtra("data");

        captureManager = new ScreenCaptureManager(this, resultCode, data);
        imageReader    = captureManager.startCapture();

        setupOverlay();
        startFrameLoop();

        return START_NOT_STICKY;
    }

    // === Уведомление для Foreground Service ===
    private void startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Virtual Window",
                NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }

        Notification notif = new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Virtual Window")
            .setContentText("Захват экрана активен")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build();

        startForeground(NOTIF_ID, notif);
    }

    // === Создаём overlay ===
    private void setupOverlay() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        // --- Параметры для основного виртуального окна ---
        WindowManager.LayoutParams winParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        winParams.gravity = Gravity.TOP | Gravity.START;

        windowView = new VirtualWindowView(this, windowManager, winParams);
        windowManager.addView(windowView, winParams);

        // --- Панель управления (кнопки внизу) ---
        WindowManager.LayoutParams panelParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        panelParams.y = 60;

        controlPanel = LayoutInflater.from(this).inflate(R.layout.overlay_controls, null);
        setupControlButtons(controlPanel);
        windowManager.addView(controlPanel, panelParams);
    }

    private void setupControlButtons(View panel) {
        Button btnZoomIn  = panel.findViewById(R.id.btn_zoom_in);
        Button btnZoomOut = panel.findViewById(R.id.btn_zoom_out);
        Button btnReset   = panel.findViewById(R.id.btn_reset);
        Button btnClose   = panel.findViewById(R.id.btn_close);

        btnZoomIn.setOnClickListener(v -> windowView.zoomIn());
        btnZoomOut.setOnClickListener(v -> windowView.zoomOut());
        btnReset.setOnClickListener(v -> windowView.resetZoom());
        btnClose.setOnClickListener(v -> stopSelf());
    }

    // === Цикл захвата кадров ===
    private void startFrameLoop() {
        frameHandler = new Handler(Looper.getMainLooper());
        isCapturing = true;

        Runnable frameRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isCapturing) return;
                captureFrame();
                frameHandler.postDelayed(this, 50); // ~20 FPS
            }
        };
        frameHandler.post(frameRunnable);
    }

    private void captureFrame() {
        if (imageReader == null) return;
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image != null) {
                Bitmap bmp = imageToBitmap(image);
                if (bmp != null) {
                    windowView.updateFrame(bmp);
                }
            }
        } catch (Exception e) {
            // пропускаем кадр при ошибке
        } finally {
            if (image != null) image.close();
        }
    }

    private Bitmap imageToBitmap(Image image) {
        try {
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride  = planes[0].getPixelStride();
            int rowStride    = planes[0].getRowStride();
            int rowPadding   = rowStride - pixelStride * image.getWidth();

            Bitmap bmp = Bitmap.createBitmap(
                image.getWidth() + rowPadding / pixelStride,
                image.getHeight(),
                Bitmap.Config.ARGB_8888
            );
            bmp.copyPixelsFromBuffer(buffer);
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onDestroy() {
        isCapturing = false;
        if (frameHandler != null) frameHandler.removeCallbacksAndMessages(null);
        if (captureManager != null) captureManager.stop();
        if (windowView != null)    windowManager.removeView(windowView);
        if (controlPanel != null)  windowManager.removeView(controlPanel);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
